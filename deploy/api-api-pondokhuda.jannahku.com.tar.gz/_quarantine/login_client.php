<?php

include ('kon.php');

$kode = $_POST['kode'];
$pin = $_POST['pin'];

// $kode = "000001";
// $pin = '123g456';

$koneksi = mysqli_connect($host, $user, $pass, $daba);

if( !$koneksi)
{
	return;
}

// cek apakah input kosong?
if( $kode != "" && $pin != "")
{
    if( substr($kode, 0, 1) == "o" && substr($kode, strlen($kode), 1) == "w" && strlen($kode) == 8)
    {
        echo "ini owner";
    }
    else if( substr($kode, 0, 1) == "a" && substr($kode, strlen($kode), 1) == "d")
    {
        echo "ini admin";
    }
    else if( substr($kode, 0, 1) == "p" || substr($kode, 0, 1) == "u")
    {
        echo "ini penyewa";
    }
    else 
    {
        echo "dont know";
    }
    
    // // get data pembayaran client
    
    // // get data diri client (gabungin data pembayaran ke satu json)
    // $queryBiodata = "SELECT * FROM tb_penyewa WHERE kode = '$kode' AND nomorpin = '$pin'";
    // $result = mysqli_query($koneksi, $queryBiodata);
    // $jsonfinal = array();
    
    // if( mysqli_num_rows($result) == 1)
    // {
    //     while($rows = mysqli_fetch_assoc($result))
    //     {
    //         $jsonfinal[] = array(
    //             "kode" => $rows['kode'],
    //             "nomorktp" => $rows['noktp'],
    //             "nomorkamar" => $rows['nokamar'],
    //             "nama" => $rows['nama'],
    //             "tgllahir" => $rows['tgllahir'],
    //             "jeniskelamin" => $rows['jk'],
    //             "nomorhp" => $rows['nohp'],
    //             "email" => $rows['email'],
    //             "urlfoto" => "https://asharilabs.technology" . $rows['urlfoto'],
    //             "namaortu" => $rows['namaortu'],
    //             "nomorhportu" => $rows['nohportu'],
    //             "alamatrumah" => $rows['alamat'],
    //             "kelurahan" => $rows['kelurahan'],
    //             "kecamatan" => $rows['kecamatan'],
    //             "namakotakabupaten" => $rows['kotakab'],
    //             "kodepos" => $rows['kodepos'],
    //             "tempatkuliahkerja" => $rows['tempatkuliahkerja'],
    //             "jurusankuliah" => $rows['jurusankuliah'],
    //             "periodebayar" => $rows['periodebayar'],
    //             "status" => $rows['status'],
    //             "nomorpin" => $rows['nomorpin']
    //             );
    //     }
        
    //     echo json_encode(array('personalinfo' => $jsonfinal));
    // }
    // else
    // {
    //     echo json_encode(array('personalinfo' => "tidak ada data"));
    // }
}
else
{
    echo json_encode(array('personalinfo' => 'inputkurang'));
}
?>