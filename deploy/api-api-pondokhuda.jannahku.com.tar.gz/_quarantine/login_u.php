<?php

include("kon.php");

// get POST variable
//$username = $_POST['uname'];
$kode = $_POST['kode'];
$pin = $_POST['pin'];

$kode = "000001";
$pin = '12345';

$koneksi = mysqli_connect($host, $user, $pass, $daba);

if( !$koneksi)
{
	return;
}

// $queryGetDataBayaran = "SELECT 
// 	bayarke AS ke, 
//         tgl_bayar AS tgl,
//         besar_bayar AS bayar,
//         keterangan_bayar AS ket1,
//         keterangan_waktu AS ket2       
// FROM tb_bayaran 
// WHERE id_user = (SELECT tb_pengguna.id_pengguna FROM tb_pengguna 
// 	WHERE tb_pengguna.usr_pengguna = '$username' AND tb_pengguna.pwd_pengguna = '$password')";
$queryGetDataBayaran = "SELECT 
	bayarke AS ke, 
	nota,
        tgl_bayar AS tgl,
        besar_bayar AS bayar,
        keterangan_bayar AS ket1,
        keterangan_waktu AS ket2       
FROM tb_bayaran 
WHERE id_user = (SELECT tb_pengguna.id_pengguna FROM tb_pengguna 
	WHERE tb_pengguna.pin = '$pin' AND tb_pengguna.pwd_pengguna = '$password')";

$result1 = mysqli_query($koneksi, $queryGetDataBayaran);
$databayaranuser = array();

if( mysqli_num_rows($result1) > 0)
{
	while ($rows = mysqli_fetch_assoc($result1)) {
		
		$databayaranuser[] = array(
			"ke" => $rows['ke'],
			"nota" => $rows['nota'],
			"tgl" => $rows['tgl'],
			"bayar" => $rows['bayar'],
			"ket1" => $rows['ket1'],
			"ket2" => $rows['ket2']
		);
	}
}
else
{
	$databayaranuser = null;
}

// $query = "SELECT id_pengguna AS id, no_kamar AS nokmr, nama_pengguna AS nama, alamat_pengguna AS alamat, 
// usr_pengguna AS uname, pwd_pengguna AS pword, tgllahir_pengguna AS tgllhr, 
// foto_pengguna AS foto, institusi_pengguna AS institusi, 
// subinstitusi_pengguna AS subIns
//  FROM tb_pengguna WHERE usr_pengguna = '" . $username . "' AND pwd_pengguna = '" . $password . "'";
$query = "SELECT id_pengguna AS id, no_kamar AS nokmr, nama_pengguna AS nama, alamat_pengguna AS alamat, nohp,
usr_pengguna AS uname, pwd_pengguna AS pword, pin, tgllahir_pengguna AS tgllhr, 
foto_pengguna AS foto, institusi_pengguna AS institusi, 
subinstitusi_pengguna AS subIns,
status_kost AS status
 FROM tb_pengguna WHERE tb_pengguna.pin = '$pin' AND tb_pengguna.pwd_pengguna = '$password' AND status_kost = 'Y'";
 
$result = mysqli_query($koneksi, $query);

$rowsCount = mysqli_num_rows($result);
$jsonArrUser = array();

if( $rowsCount == 1)
{

	while ($rows = mysqli_fetch_assoc($result)) {
		
		$jsonArrUser[] = array(
			"id" => $rows['id'],
			"nokmr" => $rows['nokmr'],
			"nama" => $rows['nama'],
			"alamat" => $rows['alamat'],
			"nohp" => $rows['nohp'],
			"uname" => $rows['uname'],
			"pword" => $rows['pword'],
			"pin" => $rows['pin'],
			"tgllhr" => $rows['tgllhr'],
			"foto" => $rows['foto'],
			"institusi" => $rows['institusi'],
			"subIns" => $rows['subIns'],
			"status" => $rows['status'],
			"bayarankost" => $databayaranuser
		);
	}

	echo json_encode($jsonArrUser);
}
else
{
	echo "gagal";
}

// -------------------------------------------------- get data history bayar


?>