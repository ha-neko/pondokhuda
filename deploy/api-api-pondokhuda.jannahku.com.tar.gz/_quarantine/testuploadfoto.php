<?php

include ('kon.php');

$connect = mysqli_connect($host, $user, $pass, $daba);
if( !$connect)
    return;

echo "berhasil";
?>