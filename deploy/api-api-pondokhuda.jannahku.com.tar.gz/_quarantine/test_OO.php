<?php

class Connection
{
    // $host; 
    // $user; 
    // $pass;
    // $db;
    
    function GetConnection($h, $u, $p, $d)
    {
        
    }
}

?>