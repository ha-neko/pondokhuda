<?php
include '../pdf/TCPDF-master/tcpdf.php';
$pdf = new TCPDF();
$pdf->AddPage('P', 'A4');
$img_file = '../kwitansi/template-invoice.jpg';
$pdf->Image($img_file, 0, 0, 235, 297, '', '', '', false, 300, '', false, false, 0);
$html = '<html><head></head><body><table border="1" width="100%" cellpadding="0" cellspacing="0"><tr><td height="20px" colspan="3" width="100%"></td></tr><tr><td colspan="3" width="100%"><img src="https://img.freepik.com/free-icon/web-page-home_318-85928.jpg?size=338c&ext=jpg" height="60px" width="60px"></td></tr><tr><td width="50%"></td><td align="right" width="47%" style="font-family:arial;">No._____________________</td><td width="3%"></td></tr><tr><td colspan="3" height="90px"></td></tr><tr><td width="20%">Telah diterima dari</td><td width="10%" align="right">: </td><td width="70%"> Ucok dari Goa Hantu</td></tr><tr><td colspan="3"></td></tr><tr><td width="20%">Uang Sebesar</td><td width="10%" align="right">: </td><td width="70%"> Rp XXXXXXX</td></tr><tr><td colspan="3"></td></tr><tr><td width="20%">Untuk pembayaran</td><td width="10%" align="right">: </td><td width="70%"> Sewa Kost</td></tr><tr><td colspan="3" height="100px"></td></tr><tr><td width="50%"></td><td width="47%" align="right">Tanggal, ______________</td><td width="3%"></td></tr></table></body></html>';

$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Output();

// Save PDF to server
// $pdf->Output('/home/pondokhu/public_html/kwitansi/test.pdf', 'F');
?>