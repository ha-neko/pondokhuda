<?php
include('test_OO.php');

$k = new Connection();

if( $k->GetConnection("localhost", "pondokhu_user", "pondokhupassword", "pondokhu_pondokhuda"))
{
    echo "berhasil";
}
else
{
    echo "tidak";
}
?>