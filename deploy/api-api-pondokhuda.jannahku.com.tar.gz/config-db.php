<?php
return array (
  'db' => 
  array (
    'host' => 'localhost',
    'user' => 'u1642799_BdGadm',
    'pass' => 'D3v4apps@$22glob',
    'name' => 'u1642799_pondokhuda',
  ),
  'tokens' => 
  array (
    0 => 'pondokhuda-prod-2026',
  ),
);
